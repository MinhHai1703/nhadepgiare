import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

const properties = [
  {
    id: 1,
    title: "Nhà cấp 4 tại Quận 12",
    price: "1.2 tỷ",
    location: "Quận 12, TP. HCM",
    image: "https://via.placeholder.com/400x250",
  },
  {
    id: 2,
    title: "Căn hộ mini Gò Vấp",
    price: "950 triệu",
    location: "Gò Vấp, TP. HCM",
    image: "https://via.placeholder.com/400x250",
  },
  {
    id: 3,
    title: "Nhà phố Bình Tân",
    price: "1.8 tỷ",
    location: "Bình Tân, TP. HCM",
    image: "https://via.placeholder.com/400x250",
  },
];

export default function App() {
  return (
    <div className="p-6 space-y-8">
      <header className="text-center space-y-2">
        <h1 className="text-4xl font-bold text-green-600">Nhà Đẹp Giá Rẻ</h1>
        <p className="text-lg text-gray-600">Tìm ngôi nhà mơ ước với giá phù hợp</p>
      </header>

      <div className="flex items-center max-w-xl mx-auto gap-2">
        <Input placeholder="Tìm kiếm theo khu vực hoặc giá..." className="flex-1" />
        <Button variant="outline">
          <Search className="w-4 h-4" />
        </Button>
      </div>

      <section className="grid md:grid-cols-3 gap-6">
        {properties.map((property) => (
          <Card key={property.id} className="rounded-2xl overflow-hidden shadow-md">
            <img src={property.image} alt={property.title} className="w-full h-48 object-cover" />
            <CardContent className="p-4 space-y-2">
              <h2 className="text-xl font-semibold text-gray-800">{property.title}</h2>
              <p className="text-green-600 font-bold">{property.price}</p>
              <p className="text-gray-500 text-sm">{property.location}</p>
              <Button className="w-full mt-2">Xem chi tiết</Button>
            </CardContent>
          </Card>
        ))}
      </section>
    </div>
  );
}
